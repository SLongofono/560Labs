Container::Container()
{	
	this.value = -1;
	this.flag = false;
}