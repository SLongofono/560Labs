#ifndef ORDER_H
#define ORDER_H

enum Order{PRE_ORDER,
	IN_ORDER,
	LEVEL_ORDER};

#endif 
