#ifndef SNODE_H
#define SNODE_H

class SNode
{
	public:
		SNode();
		SNode* left;
		SNode* right;
		int value;
};
#include "SNode.hpp"
#endif
