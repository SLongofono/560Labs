
SNode::SNode()
{
	left = nullptr;
	right = nullptr;
	value = 0;
}
